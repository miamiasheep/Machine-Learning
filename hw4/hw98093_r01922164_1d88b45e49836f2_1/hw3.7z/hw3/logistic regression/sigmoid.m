function ans=sigmoid(s)
    ans=exp(s)/(1+exp(s));
end